"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    jwtSecret: '#34_!gTY'
};
//# sourceMappingURL=config.js.map