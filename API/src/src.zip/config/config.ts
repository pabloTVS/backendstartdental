export default {
  jwtSecret: '#34_!gTY'
};
